package com.unanimous;

public class MyUtils {
    public final static String str(float obj) {
        return String.valueOf(obj);
    }
}